package com.example.patient.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.patient.model.Patient;
import com.example.patient.service.PatientService;

import java.util.List;

@RestController
@RequestMapping("/patients")
public class PatientController {

  @Autowired
  PatientService service;

    @PostMapping
    public ResponseEntity<?> addPatient(@RequestBody Patient patient) {
        patient = service.addPatient(patient);
        return ResponseEntity.status(201).body(patient);
    }

    @GetMapping
    public ResponseEntity<?> getAllPatients() {
        List<Patient> list = service.getAllPatients();
        if (list.isEmpty()) {
            return ResponseEntity.status(404).body("No patients found");
        }
        return ResponseEntity.status(200).body(list);
    }


    @DeleteMapping("/{patientId}")
    public ResponseEntity<?> deletePatient(@PathVariable Long patientId) {
        Boolean isDeleted = service.deletePatient(patientId);
        if (!isDeleted) {
            return ResponseEntity.status(404).body("Patient with ID " + patientId + " not found");
        }
        return ResponseEntity.status(204).body("Patient deleted successfully");
    }
}
