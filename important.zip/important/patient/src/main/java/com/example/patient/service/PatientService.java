package com.example.patient.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.patient.model.Patient;
import com.example.patient.repository.PatientRepo;

import java.util.List;

@Service
public class PatientService {
@Autowired
   PatientRepo repo;

    // Add a new patient
    public Patient addPatient(Patient patient) {
        return repo.save(patient);
    }

    // Retrieve all patients
    public List<Patient> getAllPatients() {
        return repo.findAll();
    }

    // Delete a patient by ID
    public Boolean deletePatient(Long patientId) {
        Patient existPatient = repo.findById(patientId).orElse(null);
        if (existPatient == null) {
            return false;
        }
        repo.delete(existPatient);
        return true;
    }
}

