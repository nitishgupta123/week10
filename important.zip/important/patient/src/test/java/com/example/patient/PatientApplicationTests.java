package com.example.patient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
