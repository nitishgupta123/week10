package com.examly.springapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmAidApplicationTests {

	@Test
	void contextLoads() {
	}

}
