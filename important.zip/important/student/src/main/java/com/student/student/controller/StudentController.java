package com.student.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.student.model.Student;
import com.student.student.service.StudentService;

@RestController
public class StudentController {

    @Autowired
    StudentService service;

    @PostMapping("/student")
    public ResponseEntity<?> addStudent(@RequestBody Student student){
        student = service.addStudent(student);
        return ResponseEntity.status(201).body(student);
    }

    @GetMapping("/student")
    public ResponseEntity<?> getAllStudents(){
        List<Student> list = service.getAllStudents();
        if (list.isEmpty()) {
            return ResponseEntity.status(404).body("No students found");
        }
        return ResponseEntity.status(200).body(list);
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getStudentById(@PathVariable int studentId){
        Student student = service.getStudentById(studentId);
        if (student == null) {
            return ResponseEntity.status(404).body("Student with ID " + studentId + " not found");
        }
        return ResponseEntity.status(200).body(student);
    }

    @DeleteMapping("/student/{studentId}")
    public ResponseEntity<?> deleteStudent(@PathVariable int studentId){
        Boolean isDeleted = service.deleteStudent(studentId);
        if (!isDeleted) {
            return ResponseEntity.status(404).body("Student with ID " + studentId + " not found");
        }
        return ResponseEntity.status(200).body("Student deleted successfully");
    }

    @PutMapping("/student/{studentId}")
    public ResponseEntity<?> updateStudent(@PathVariable int studentId, @RequestBody Student updatedStudent){
        Student student = service.updateStudent(studentId, updatedStudent);
 
        return ResponseEntity.status(200).body(student);
    }
}


