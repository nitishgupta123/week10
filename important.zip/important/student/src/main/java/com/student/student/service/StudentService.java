package com.student.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.student.model.Student;
import com.student.student.repository.StudentRepo;

@Service
public class StudentService {
	@Autowired
	StudentRepo repo;
    
	public Student addStudent(Student student) {
		return repo.save(student);
	}
	
	public List<Student> getAllStudents() {
		return repo.findAll();
	}

	public Student getStudentById(int studentId) {
		return repo.findById(studentId).orElse(null);
	}

	public Boolean deleteStudent(int studentId) {
		Student existStudent=repo.findById(studentId).orElse(null);
		if(existStudent==null)
			return false;
		repo.delete(existStudent);
		return true;
	}

	public Student updateStudent(int studentId, Student updatedStudent) {
		Student st=repo.findById(studentId).orElse(null);
        if(st==null)
            return null;

        updatedStudent.setStudentId(studentId);
        return repo.save(updatedStudent);
	}

}
